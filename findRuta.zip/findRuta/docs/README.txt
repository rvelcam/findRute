Carpeta para alojar documentaci�n de inter�s para el proyecto. Puede usarse para cualquier tipo de documentaci�n, instrucciones, manuales, etc.
Usad nombres descriptivos. 
Ficheros que contiene:
 -httpd-xampp.conf: Contiene la configuraci�n que utilizamos en Apache.
 -configuracionApache: documento explicativo de los pasos seguidos para configurar nuestro Apache.