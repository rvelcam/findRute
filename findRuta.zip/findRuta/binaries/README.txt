Esta carpeta contiene los binarios generados en el proyecto, si los hubiera.
Las instrucciones de uso deben incluirse en la carpeta docs.