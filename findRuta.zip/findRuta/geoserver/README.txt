Carpeta de configuraci�n de Geoserver.
Debe contener la estructura completa del workspace que se est� configurando para el proyecto.
Incluid al final de este documento de texto explicando los datasources locales y otros nombres de recursos que haya que cambiar para hacer la instalaci�n en otros servidores.