Esta carpeta debe contener los scripts JavaScript y los documentos html necesarios para ejecutar el cliente de los prototipos.
Esta carpeta se publicar� directamente en un servidor Web.
Si en el dise�o final de la aplicaci�n combina html y php los ficheros deben ponerse en la carpeta "server".