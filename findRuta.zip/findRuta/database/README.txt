Scripts de base de datos.

En esta carpeta deben ponerse los scripts de creaci�n del esquema de base de datos, la carga inicial de datos de prototipo y los scripts definitivos.
